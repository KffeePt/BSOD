# socat-windows


unofficial build of socat 
http://www.dest-unreach.org/socat/

built with cygwin

output of socat -V

	socat by Gerhard Rieger - see www.dest-unreach.org
	socat version 1.7.2.1 on May 16 2012 00:59:02
	   running on CYGWIN_NT-6.1-WOW64 version 2012-05-09 10:25, release 1.7.15(0.260
	/5/3), machine i686
	features:
	  #define WITH_STDIO 1
	  #define WITH_FDNUM 1
	  #define WITH_FILE 1
	  #define WITH_CREAT 1
	  #define WITH_GOPEN 1
	  #define WITH_TERMIOS 1
	  #define WITH_PIPE 1
	  #define WITH_UNIX 1
	  #undef WITH_ABSTRACT_UNIXSOCKET
	  #define WITH_IP4 1
	  #undef WITH_IP6
	  #define WITH_RAWIP 1
	  #define WITH_GENERICSOCKET 1
	  #undef WITH_INTERFACE
	  #define WITH_TCP 1
	  #define WITH_UDP 1
	  #undef WITH_SCTP
	  #define WITH_LISTEN 1
	  #define WITH_SOCKS4 1
	  #define WITH_SOCKS4A 1
	  #define WITH_PROXY 1
	  #define WITH_SYSTEM 1
	  #define WITH_EXEC 1
	  #define WITH_READLINE 1
	  #undef WITH_TUN
	  #define WITH_PTY 1
	  #define WITH_OPENSSL 1
	  #undef WITH_FIPS
	  #define WITH_LIBWRAP 1
	  #define WITH_SYCLS 1
	  #define WITH_FILAN 1
	  #define WITH_RETRY 1
	  #define WITH_MSGLEVEL 0 /*debug*/